<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");

    //Conexao com banco de dados
    try{
        $conexao = new PDO('mysql:host=localhost;dbname=tripwiser_matheus', 'tripwiser_matheus', 'fLbS7umPWRVsYSXss6gY');
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "ok";
    }catch(PDOException $e){
        echo $e;
    }

?>

<?php

    try{
        $resultado = $conexao->prepare("SELECT * FROM clientes");
        $resultado->execute();

            $contar = $resultado->rowCount();

        if($contar > 0){
            while($mostrar = $resultado->fetchAll(PDO::FETCH_ASSOC)){
                echo json_encode($mostrar);
            }
        }

        }catch(PDOException $e){
            echo $e;
        }

?>