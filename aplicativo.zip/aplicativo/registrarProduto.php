<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
require_once './Conexao.php';

try {
    $custo_producao = $_POST['custo_producao'] ?? null;
    $custo_venda = $_POST['custo_venda'] ?? null;
    $nome = $_POST['nome'] ?? null;

    if (empty($custo_producao) || empty($custo_venda) || empty($nome)) {
        echo json_encode([
            "status" => "error",
            "message" => "Parâmetros inválidos"
        ]);
        exit();
    }

    $sql = "INSERT INTO produto (created_at, custo_producao, custo_venda, nome, dtdelete) 
            VALUES (NOW(), :custo_producao, :custo_venda, :nome, NULL)";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':custo_producao', $custo_producao);
    $stmt->bindParam(':custo_venda', $custo_venda);
    $stmt->bindParam(':nome', $nome);
    $stmt->execute();
    
    $sql = "SELECT id, created_at, custo_producao, custo_venda, nome, dtdelete 
            FROM produto
            ORDER BY created_at DESC";
    $stmt = $conexao->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "message" => "Produto cadastrado com sucesso.",
        "data" => $result
    ]);

} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Erro de Conexão com o Servidor"
    ]);
    exit();
}
