<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
require_once './Conexao.php';

try {
    $data = $_POST['data'] ?? null;         
    $valor = $_POST['valor'] ?? null;
    $produto_id = $_POST['produto_id'] ?? null;
    $quantidade = $_POST['quantidade'] ?? null;

    if (empty($data) || empty($valor) || empty($produto_id) || empty($quantidade)) {
        echo json_encode([
            "status" => "error",
            "message" => "Parâmetros inválidos"
        ]);
        exit();
    }
    $sql = "INSERT INTO vendas (created_at, data, valor, produto_id, quantidade, dtdelete) 
            VALUES (NOW(), :data, :valor, :produto_id, :quantidade, NULL)";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':data', $data);
    $stmt->bindParam(':valor', $valor);
    $stmt->bindParam(':produto_id', $produto_id);
    $stmt->bindParam(':quantidade', $quantidade);
    $stmt->execute();
    $sql = "SELECT id, created_at, data, valor, produto_id, quantidade, dtdelete 
            FROM vendas 
            ORDER BY created_at DESC";
    $stmt = $conexao->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "message" => "Venda registrada com sucesso.",
        "data" => $result
    ]);

} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Erro de Conexão com o Servidor"
    ]);
   exit();
}
