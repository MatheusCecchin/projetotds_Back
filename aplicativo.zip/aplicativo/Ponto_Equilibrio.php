<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
require_once './Conexao.php';

try {
    $id_usuario = $_POST['id_usuario'];
    $data = $_POST['data'];
    $custos_fixos = $_POST['custos_fixos'];
    $custos_variavies = $_POST['custos_variavies'];
    $preco_venda = $_POST['preco_venda'];


    if (empty($user_id) || empty($data) || empty($custos_fixos) || empty($custos_variavies)) {
        echo json_encode([
            "status" => "error",
            "message" => "Parâmetros inválidos"
        ]);
        exit();
    }

    // Insere no banco
    $sql = "INSERT INTO ponto_equilibrio (id_usuario, data, custos_fixos, custos_variaveis, preco_venda) 
            VALUES (:id_usuario, :data, :custos_fixos, :custos_variaveis, :preco_venda)";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id_usuario', $id_usuario);
    $stmt->bindParam(':data', $data);
    $stmt->bindParam(':custos_fixos', $custos_fixos);
    $stmt->bindParam(':custos_variaveis', $custos_variavies);
    $stmt->bindParam(':preco_venda', $preco_venda);
    $stmt->execute();

    //busca valores inseridos
    $sql = "SELECT * FROM ponto_equilibrio WHERE id_usuario = :id_usuario ORDER BY data DESC";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id_usuario', $id_usuario);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "message" => "Certificado cadastrado com sucesso.",
        "data" => $result
    ]);

} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Erro de Conexão com o Servidor"
    ]);
    exit();
}
